<?php
	session_start();
	$username = $_POST["username"]; // This is the inputted username from the form in Login.html
	$password = $_POST["password"]; // This is the inputted password from the form in Login.html

	mysql_connect('*** INSERT YOUR DATABASE URL HERE ***','*** USERNAME?? ***','*** PASSWORD?? ***'); // *** INSERT YOUR DATABSE INFORMATION HERE ***
	mysql_select_db('*** INSERT YOUR DATABASE NAME HERE ***') or die('Could not select database');

	$sql="SELECT * FROM members WHERE username='$username' AND password='$password'"; $result=mysql_query($sql);

	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result); // Check if supplied user, password, match database

	if($count==1) // If there is a match..
	{
		$_SESSION["username"] = $username; // Creates a cookie saving the username
		$_SESSION["loggedIn"] = true; // Creates a cookie saying the user is logged in
		header("Location:ProtectedPage.php");
	}else{ // If invalid information was entered
		header("Location:Login.html"); // Lastly, redirect back to login page
	}
?>